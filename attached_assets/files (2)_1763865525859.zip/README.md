# 🗨️ AutoForce™ Chat UI Components

**WhatsApp-style chat interface for mobile and desktop**

---

## 📦 Components

### 1. MobileChatList.tsx (18KB)
WhatsApp-inspired chat list for mobile devices.

**Features:**
- ✅ Swipe actions (mute, archive, delete)
- ✅ Unread badges
- ✅ Online status indicators
- ✅ Search and filter (All, Unread, Groups, Direct)
- ✅ Pull to refresh ready
- ✅ Pinned conversations
- ✅ Typing indicators
- ✅ Message previews with icons
- ✅ Safe area support (notch/home indicator)

### 2. MobileChatView.tsx (16KB)
Full-screen chat conversation for mobile.

**Features:**
- ✅ iOS/Android-like interface
- ✅ Message bubbles with status (sent, delivered, read)
- ✅ Reactions (long press)
- ✅ Reply to messages
- ✅ Date dividers
- ✅ Attachment menu (photos, camera, files, location)
- ✅ Voice message button
- ✅ Scroll to bottom button
- ✅ Action sheet for message options

### 3. DesktopChat.tsx (32KB)
Slack/Teams-inspired desktop layout.

**Features:**
- ✅ Three-column layout (workspaces, channels, chat)
- ✅ Collapsible categories
- ✅ Rich message composer
- ✅ Reactions with emoji picker
- ✅ Reply threads ready
- ✅ Chat info panel
- ✅ Member list
- ✅ Shared media gallery
- ✅ Keyboard shortcuts ready

### 4. ChatApp.tsx (6KB)
Responsive wrapper that auto-switches layouts.

**Features:**
- ✅ Automatic mobile/desktop detection
- ✅ Shared socket connection
- ✅ React Context for state
- ✅ Customizable breakpoint

---

## 🚀 Quick Start

### Installation

```bash
# Copy files to your project
cp -r chat-ui/ your-project/src/components/

# Install dependencies
npm install socket.io-client lucide-react
```

### Basic Usage

```tsx
import ChatApp from './components/chat-ui/ChatApp';

function App() {
  return (
    <ChatApp
      userId="user_123"
      userName="John Doe"
      workspaceId="workspace_456"
      serverUrl="http://localhost:3001"
      primaryColor="#6366f1"
    />
  );
}
```

### Mobile Only

```tsx
import MobileChatList from './components/chat-ui/MobileChatList';
import MobileChatView from './components/chat-ui/MobileChatView';

function MobileChat() {
  const [selectedChat, setSelectedChat] = useState(null);

  if (selectedChat) {
    return (
      <MobileChatView
        chat={selectedChat}
        userId="user_123"
        onBack={() => setSelectedChat(null)}
        primaryColor="#6366f1"
      />
    );
  }

  return (
    <MobileChatList
      userId="user_123"
      workspaceId="workspace_456"
      onSelectChat={setSelectedChat}
      primaryColor="#6366f1"
    />
  );
}
```

### Desktop Only

```tsx
import DesktopChat from './components/chat-ui/DesktopChat';

function DesktopChatPage() {
  return (
    <DesktopChat
      userId="user_123"
      userName="John Doe"
      workspaceId="workspace_456"
      serverUrl="http://localhost:3001"
      primaryColor="#6366f1"
    />
  );
}
```

---

## 📱 Screenshots

### Mobile Chat List
```
┌─────────────────────────────┐
│ Chats                    🔍 + │
├─────────────────────────────┤
│ [All] [Unread 3] [Groups]   │
├─────────────────────────────┤
│ 📌 Morning Shift - Nov 21   │
│    Sarah: Can someone...  3 │
│    5 min ago                │
├─────────────────────────────┤
│ 🟢 Mike Johnson             │
│    Thanks for covering!     │
│    15 min ago               │
├─────────────────────────────┤
│ 🔇 Management Team          │
│    📎 Q4_Schedule_Draft.xlsx│
│    45 min ago               │
└─────────────────────────────┘
```

### Mobile Chat View
```
┌─────────────────────────────┐
│ ← Morning Shift     📹 📞 ⋮ │
├─────────────────────────────┤
│        Today                │
│                             │
│        ┌─────────────────┐  │
│        │ Can someone     │  │
│   ┌────│ cover at 2pm?   │  │
│   │    │         10:30 ✓✓│  │
│   │    └─────────────────┘  │
│   │                         │
│   │  ┌─────────────────┐    │
│   │  │ I can cover!    │    │
│   │  │         10:35 ✓✓│    │
│   │  └─────────────────┘    │
│   │              👍 2       │
├─────────────────────────────┤
│ 📎 [Message...         😊] 🎤│
└─────────────────────────────┘
```

### Desktop Layout
```
┌──┬────────────┬──────────────────────────────────────┬────────┐
│🏢│ #general   │ Morning Shift - Nov 21              │ Details│
│🌴│ #announce  │ 8 members                           │        │
│  │ #random    ├──────────────────────────────────────┤ Avatar │
│──│            │                                      │        │
│🔔│ ▼ Shifts   │ Sarah Chen                10:30 AM  │ Members│
│⚙️│   Morning  │ Can someone cover at 2pm?           │  • Mike│
│  │   Evening  │                                      │  • Emma│
│  │            │ Mike Johnson              10:35 AM  │  • Lisa│
│👤│ ▼ DMs      │ I can cover!                        │        │
│  │   Mike     │ 👍 2                                │ Media  │
│  │   Emma     │                                      │ [📷][📷]│
│  │   Sarah    │──────────────────────────────────────│        │
│  │            │ [+] Message #morning-shift      [📎]│        │
└──┴────────────┴──────────────────────────────────────┴────────┘
```

---

## 🎨 Customization

### Colors

```tsx
<ChatApp
  primaryColor="#10b981"  // Emerald
  // or
  primaryColor="#ef4444"  // Red
  // or
  primaryColor="#8b5cf6"  // Purple
/>
```

### Breakpoints

```tsx
<ChatApp
  mobileBreakpoint={1024}  // Use mobile layout up to 1024px
/>
```

### Chat Types

The components support these chat types:

| Type | Icon | Use Case |
|------|------|----------|
| `direct` | Avatar | 1:1 conversations |
| `group` | 👥 | Team chats |
| `shift` | 🕐 | Shift-based chats |
| `channel` | # | Public channels |
| `support` | 💬 | Support tickets |

---

## 🔌 Socket.io Integration

### Events Emitted

```typescript
// Register user
socket.emit('register', { id, name, role, workspaceId });

// Load chats
socket.emit('chats:load', { workspaceId });

// Join conversation
socket.emit('conversation:join', conversationId);

// Send message
socket.emit('message:send', { conversationId, content, type });

// Typing indicators
socket.emit('typing:start', conversationId);
socket.emit('typing:stop', conversationId);
```

### Events Received

```typescript
// Connection
socket.on('registered', () => {});
socket.on('chats:loaded', (chats) => {});

// Messages
socket.on('message:new', (message) => {});
socket.on('conversation:history', (messages) => {});

// Updates
socket.on('chat:updated', (chat) => {});
socket.on('typing:update', ({ conversationId, users }) => {});
```

---

## 📁 File Structure

```
chat-ui/
├── MobileChatList.tsx    # Mobile chat list (WhatsApp-style)
├── MobileChatView.tsx    # Mobile conversation view
├── DesktopChat.tsx       # Desktop three-column layout
├── ChatApp.tsx           # Responsive wrapper
└── README.md             # This file
```

---

## 🎯 Props Reference

### ChatApp

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `userId` | string | required | Current user ID |
| `userName` | string | required | Current user name |
| `userAvatar` | string | - | User avatar URL |
| `workspaceId` | string | required | Workspace ID |
| `serverUrl` | string | `http://localhost:3001` | Socket server URL |
| `primaryColor` | string | `#6366f1` | Theme color |
| `mobileBreakpoint` | number | `768` | Mobile/desktop breakpoint |

### MobileChatList

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `userId` | string | required | Current user ID |
| `workspaceId` | string | required | Workspace ID |
| `onSelectChat` | function | required | Chat selection handler |
| `onNewChat` | function | - | New chat button handler |
| `selectedChatId` | string | - | Currently selected chat |
| `primaryColor` | string | `#6366f1` | Theme color |

### MobileChatView

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `chat` | ChatRoom | required | Chat room object |
| `userId` | string | required | Current user ID |
| `onBack` | function | required | Back button handler |
| `primaryColor` | string | `#6366f1` | Theme color |

### DesktopChat

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `userId` | string | required | Current user ID |
| `userName` | string | required | Current user name |
| `userAvatar` | string | - | User avatar URL |
| `workspaceId` | string | required | Workspace ID |
| `serverUrl` | string | `http://localhost:3001` | Socket server URL |
| `primaryColor` | string | `#6366f1` | Theme color |

---

## 🔧 TypeScript Types

```typescript
interface ChatRoom {
  id: string;
  type: 'direct' | 'group' | 'shift' | 'channel' | 'support';
  name: string;
  avatar?: string;
  avatarColor?: string;
  participants?: number;
  lastMessage?: {
    content: string;
    senderId: string;
    senderName: string;
    type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location';
    timestamp: Date;
    isRead: boolean;
  };
  unreadCount: number;
  isOnline?: boolean;
  isTyping?: boolean;
  isPinned?: boolean;
  isMuted?: boolean;
}

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location' | 'system';
  timestamp: Date;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  replyTo?: Message;
  reactions?: { emoji: string; users: string[] }[];
}
```

---

## 📱 Mobile Gestures

| Gesture | Action |
|---------|--------|
| Swipe left | Show actions (mute, archive, delete) |
| Swipe right | Pin/Unpin chat |
| Long press message | Show action sheet |
| Pull down | Refresh chat list |

---

## ⌨️ Keyboard Shortcuts (Desktop)

| Shortcut | Action |
|----------|--------|
| `Enter` | Send message |
| `Shift + Enter` | New line |
| `Cmd/Ctrl + K` | Search (ready) |
| `Escape` | Close panels |

---

## 🎨 CSS Requirements

Add to your global CSS:

```css
/* Hide scrollbar but keep functionality */
.scrollbar-hide::-webkit-scrollbar {
  display: none;
}
.scrollbar-hide {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

/* Safe area support for iOS */
@supports (padding: env(safe-area-inset-top)) {
  .safe-area-top {
    padding-top: env(safe-area-inset-top);
  }
  .safe-area-bottom {
    padding-bottom: env(safe-area-inset-bottom);
  }
}
```

---

## 📦 Dependencies

```json
{
  "dependencies": {
    "socket.io-client": "^4.7.4",
    "lucide-react": "^0.263.1",
    "react": "^18.0.0"
  }
}
```

---

## 🚀 Production Tips

1. **Virtualization**: For 1000+ chats, add `react-window` or `react-virtuoso`
2. **Image optimization**: Use lazy loading for avatars
3. **PWA support**: Add service worker for offline messages
4. **Push notifications**: Integrate with Firebase/OneSignal
5. **Voice messages**: Add MediaRecorder API integration

---

## 📄 License

MIT - Built for AutoForce™

---

**Built with ❤️ for AutoForce™ | Production-Ready | Mobile-First**
