// ============================================================================
// AUTOFORCE™ CHAT LIST - Mobile WhatsApp-Style Interface
// ============================================================================
// Features:
// - WhatsApp-inspired design
// - Swipe actions (archive, mute, delete)
// - Unread badges
// - Online status indicators
// - Search and filter
// - Pull to refresh
// - Optimized for mobile touch
// ============================================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Search, Plus, MoreVertical, Users, User, Hash, Bell, BellOff,
  Archive, Trash2, Pin, Check, CheckCheck, Image, Mic, Video,
  Phone, FileText, MapPin, Clock, ChevronRight, Settings,
  MessageCircle, Filter, X, Star, Volume2, VolumeX
} from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

interface ChatRoom {
  id: string;
  type: 'direct' | 'group' | 'shift' | 'channel' | 'support';
  name: string;
  avatar?: string;
  avatarColor?: string;
  participants?: number;
  
  // Last message
  lastMessage?: {
    content: string;
    senderId: string;
    senderName: string;
    type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location';
    timestamp: Date;
    isRead: boolean;
  };
  
  // Status
  unreadCount: number;
  isOnline?: boolean;
  lastSeen?: Date;
  isTyping?: boolean;
  typingUser?: string;
  
  // Settings
  isPinned?: boolean;
  isMuted?: boolean;
  isArchived?: boolean;
  
  // Metadata
  shiftId?: string;
  shiftName?: string;
  organizationId?: string;
}

interface ChatListProps {
  userId: string;
  workspaceId: string;
  onSelectChat: (chat: ChatRoom) => void;
  onNewChat?: () => void;
  selectedChatId?: string;
  primaryColor?: string;
}

// ============================================================================
// MOCK DATA (Replace with real data from Socket.io)
// ============================================================================

const MOCK_CHATS: ChatRoom[] = [
  {
    id: '1',
    type: 'shift',
    name: 'Morning Shift - Nov 21',
    avatarColor: '#10b981',
    participants: 8,
    lastMessage: {
      content: 'Can someone cover the front desk at 2pm?',
      senderId: 'user_2',
      senderName: 'Sarah',
      type: 'text',
      timestamp: new Date(Date.now() - 5 * 60000),
      isRead: false,
    },
    unreadCount: 3,
    isPinned: true,
  },
  {
    id: '2',
    type: 'direct',
    name: 'Mike Johnson',
    avatarColor: '#6366f1',
    lastMessage: {
      content: 'Thanks for covering my shift!',
      senderId: 'user_3',
      senderName: 'Mike',
      type: 'text',
      timestamp: new Date(Date.now() - 15 * 60000),
      isRead: true,
    },
    unreadCount: 0,
    isOnline: true,
  },
  {
    id: '3',
    type: 'group',
    name: 'Management Team',
    avatarColor: '#f59e0b',
    participants: 5,
    lastMessage: {
      content: '📎 Q4_Schedule_Draft.xlsx',
      senderId: 'user_4',
      senderName: 'Lisa',
      type: 'file',
      timestamp: new Date(Date.now() - 45 * 60000),
      isRead: true,
    },
    unreadCount: 0,
    isMuted: true,
  },
  {
    id: '4',
    type: 'channel',
    name: 'Announcements',
    avatarColor: '#ef4444',
    participants: 156,
    lastMessage: {
      content: 'Holiday schedule has been posted. Please check your shifts.',
      senderId: 'admin',
      senderName: 'HR Team',
      type: 'text',
      timestamp: new Date(Date.now() - 2 * 3600000),
      isRead: false,
    },
    unreadCount: 1,
    isPinned: true,
  },
  {
    id: '5',
    type: 'direct',
    name: 'Emma Wilson',
    avatarColor: '#ec4899',
    lastMessage: {
      content: '',
      senderId: 'user_5',
      senderName: 'Emma',
      type: 'text',
      timestamp: new Date(Date.now() - 3 * 3600000),
      isRead: true,
    },
    unreadCount: 0,
    isOnline: false,
    lastSeen: new Date(Date.now() - 30 * 60000),
    isTyping: true,
    typingUser: 'Emma',
  },
  {
    id: '6',
    type: 'support',
    name: 'IT Support',
    avatarColor: '#8b5cf6',
    lastMessage: {
      content: 'Your ticket #1234 has been resolved.',
      senderId: 'support',
      senderName: 'Support Bot',
      type: 'text',
      timestamp: new Date(Date.now() - 24 * 3600000),
      isRead: true,
    },
    unreadCount: 0,
  },
  {
    id: '7',
    type: 'shift',
    name: 'Evening Shift - Nov 20',
    avatarColor: '#14b8a6',
    participants: 6,
    lastMessage: {
      content: 'Great work everyone! See you tomorrow.',
      senderId: 'user_1',
      senderName: 'You',
      type: 'text',
      timestamp: new Date(Date.now() - 48 * 3600000),
      isRead: true,
    },
    unreadCount: 0,
    isArchived: false,
  },
];

// ============================================================================
// CHAT LIST COMPONENT
// ============================================================================

export default function MobileChatList({
  userId,
  workspaceId,
  onSelectChat,
  onNewChat,
  selectedChatId,
  primaryColor = '#6366f1',
}: ChatListProps) {
  // State
  const [chats, setChats] = useState<ChatRoom[]>(MOCK_CHATS);
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'unread' | 'groups' | 'direct'>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [swipedChatId, setSwipedChatId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  
  // Refs
  const listRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef(0);
  const touchStartY = useRef(0);

  // ============================================================================
  // FILTERING & SORTING
  // ============================================================================

  const filteredChats = chats
    .filter(chat => {
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          chat.name.toLowerCase().includes(query) ||
          chat.lastMessage?.content.toLowerCase().includes(query)
        );
      }
      return true;
    })
    .filter(chat => {
      // Type filter
      if (filter === 'unread') return chat.unreadCount > 0;
      if (filter === 'groups') return chat.type === 'group' || chat.type === 'shift' || chat.type === 'channel';
      if (filter === 'direct') return chat.type === 'direct';
      return !chat.isArchived;
    })
    .sort((a, b) => {
      // Pinned first
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      
      // Then by timestamp
      const timeA = a.lastMessage?.timestamp?.getTime() || 0;
      const timeB = b.lastMessage?.timestamp?.getTime() || 0;
      return timeB - timeA;
    });

  // ============================================================================
  // HANDLERS
  // ============================================================================

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate refresh - replace with actual Socket.io fetch
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsRefreshing(false);
  };

  const handleSwipeStart = (e: React.TouchEvent, chatId: string) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  };

  const handleSwipeEnd = (e: React.TouchEvent, chatId: string) => {
    const deltaX = e.changedTouches[0].clientX - touchStartX.current;
    const deltaY = Math.abs(e.changedTouches[0].clientY - touchStartY.current);
    
    // Only trigger if horizontal swipe is greater than vertical
    if (Math.abs(deltaX) > 50 && deltaY < 30) {
      if (deltaX < -50) {
        // Swipe left - show actions
        setSwipedChatId(chatId);
      } else if (deltaX > 50) {
        // Swipe right - archive or pin
        handlePin(chatId);
      }
    }
  };

  const handlePin = (chatId: string) => {
    setChats(prev => prev.map(chat => 
      chat.id === chatId ? { ...chat, isPinned: !chat.isPinned } : chat
    ));
    setSwipedChatId(null);
  };

  const handleMute = (chatId: string) => {
    setChats(prev => prev.map(chat => 
      chat.id === chatId ? { ...chat, isMuted: !chat.isMuted } : chat
    ));
    setSwipedChatId(null);
  };

  const handleArchive = (chatId: string) => {
    setChats(prev => prev.map(chat => 
      chat.id === chatId ? { ...chat, isArchived: true } : chat
    ));
    setSwipedChatId(null);
  };

  const handleDelete = (chatId: string) => {
    setChats(prev => prev.filter(chat => chat.id !== chatId));
    setSwipedChatId(null);
  };

  // ============================================================================
  // RENDER HELPERS
  // ============================================================================

  const formatTime = (date?: Date) => {
    if (!date) return '';
    
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (24 * 3600000));
    
    if (days === 0) {
      return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    } else if (days === 1) {
      return 'Yesterday';
    } else if (days < 7) {
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const getMessagePreview = (chat: ChatRoom) => {
    if (chat.isTyping) {
      return <span className="text-emerald-500 italic">typing...</span>;
    }
    
    if (!chat.lastMessage) {
      return <span className="text-gray-400">No messages yet</span>;
    }

    const { type, content, senderName, senderId } = chat.lastMessage;
    const isOwn = senderId === userId;
    const prefix = chat.type !== 'direct' && !isOwn ? `${senderName}: ` : '';
    
    let icon = null;
    let text = content;

    switch (type) {
      case 'image':
        icon = <Image className="w-4 h-4 mr-1" />;
        text = 'Photo';
        break;
      case 'video':
        icon = <Video className="w-4 h-4 mr-1" />;
        text = 'Video';
        break;
      case 'audio':
        icon = <Mic className="w-4 h-4 mr-1" />;
        text = 'Voice message';
        break;
      case 'file':
        icon = <FileText className="w-4 h-4 mr-1" />;
        break;
      case 'location':
        icon = <MapPin className="w-4 h-4 mr-1" />;
        text = 'Location';
        break;
    }

    return (
      <span className="flex items-center">
        {isOwn && (
          chat.lastMessage.isRead 
            ? <CheckCheck className="w-4 h-4 mr-1 text-blue-500 flex-shrink-0" />
            : <Check className="w-4 h-4 mr-1 text-gray-400 flex-shrink-0" />
        )}
        {icon}
        <span className="truncate">
          {prefix}{text}
        </span>
      </span>
    );
  };

  const getChatIcon = (type: ChatRoom['type']) => {
    switch (type) {
      case 'group':
        return <Users className="w-4 h-4" />;
      case 'shift':
        return <Clock className="w-4 h-4" />;
      case 'channel':
        return <Hash className="w-4 h-4" />;
      case 'support':
        return <MessageCircle className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div 
        className="sticky top-0 z-20 px-4 pt-4 pb-2 bg-white border-b"
        style={{ paddingTop: 'max(1rem, env(safe-area-inset-top))' }}
      >
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-2xl font-bold text-gray-900">Chats</h1>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowSearch(!showSearch)}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
            >
              <Search className="w-5 h-5 text-gray-600" />
            </button>
            <button 
              onClick={onNewChat}
              className="w-10 h-10 rounded-full flex items-center justify-center text-white"
              style={{ backgroundColor: primaryColor }}
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {showSearch && (
          <div className="relative mb-3">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 text-sm"
              style={{ '--tw-ring-color': primaryColor } as any}
              autoFocus
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                <X className="w-4 h-4 text-gray-400" />
              </button>
            )}
          </div>
        )}

        {/* Filter Pills */}
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
          {(['all', 'unread', 'groups', 'direct'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === f
                  ? 'text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              style={{ backgroundColor: filter === f ? primaryColor : undefined }}
            >
              {f === 'all' ? 'All' : f === 'unread' ? 'Unread' : f === 'groups' ? 'Groups' : 'Direct'}
              {f === 'unread' && chats.filter(c => c.unreadCount > 0).length > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 bg-white bg-opacity-30 rounded-full text-xs">
                  {chats.filter(c => c.unreadCount > 0).length}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Pull to Refresh Indicator */}
      {isRefreshing && (
        <div className="flex items-center justify-center py-3 bg-gray-50">
          <div className="w-5 h-5 border-2 border-gray-300 border-t-indigo-600 rounded-full animate-spin"></div>
          <span className="ml-2 text-sm text-gray-500">Refreshing...</span>
        </div>
      )}

      {/* Chat List */}
      <div 
        ref={listRef}
        className="flex-1 overflow-y-auto"
        onTouchStart={() => {
          if (listRef.current?.scrollTop === 0) {
            // Could implement pull-to-refresh here
          }
        }}
      >
        {filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <MessageCircle className="w-12 h-12 mb-3 opacity-50" />
            <p className="font-medium">No chats found</p>
            <p className="text-sm">
              {searchQuery ? 'Try a different search' : 'Start a new conversation'}
            </p>
          </div>
        ) : (
          filteredChats.map((chat) => (
            <div
              key={chat.id}
              className="relative overflow-hidden"
            >
              {/* Swipe Actions (Right) */}
              <div 
                className={`absolute inset-y-0 right-0 flex items-stretch transition-transform duration-200 ${
                  swipedChatId === chat.id ? 'translate-x-0' : 'translate-x-full'
                }`}
              >
                <button
                  onClick={() => handleMute(chat.id)}
                  className="w-16 flex flex-col items-center justify-center bg-gray-500 text-white"
                >
                  {chat.isMuted ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  <span className="text-xs mt-1">{chat.isMuted ? 'Unmute' : 'Mute'}</span>
                </button>
                <button
                  onClick={() => handleArchive(chat.id)}
                  className="w-16 flex flex-col items-center justify-center bg-blue-500 text-white"
                >
                  <Archive className="w-5 h-5" />
                  <span className="text-xs mt-1">Archive</span>
                </button>
                <button
                  onClick={() => handleDelete(chat.id)}
                  className="w-16 flex flex-col items-center justify-center bg-red-500 text-white"
                >
                  <Trash2 className="w-5 h-5" />
                  <span className="text-xs mt-1">Delete</span>
                </button>
              </div>

              {/* Chat Item */}
              <button
                onClick={() => {
                  if (swipedChatId === chat.id) {
                    setSwipedChatId(null);
                  } else {
                    onSelectChat(chat);
                  }
                }}
                onTouchStart={(e) => handleSwipeStart(e, chat.id)}
                onTouchEnd={(e) => handleSwipeEnd(e, chat.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 active:bg-gray-100 transition-all ${
                  selectedChatId === chat.id ? 'bg-indigo-50' : ''
                } ${swipedChatId === chat.id ? '-translate-x-48' : 'translate-x-0'}`}
                style={{ transition: 'transform 0.2s ease-out' }}
              >
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  <div 
                    className="w-14 h-14 rounded-full flex items-center justify-center text-white text-lg font-semibold"
                    style={{ backgroundColor: chat.avatarColor || primaryColor }}
                  >
                    {chat.avatar ? (
                      <img src={chat.avatar} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : chat.type === 'direct' ? (
                      chat.name.charAt(0).toUpperCase()
                    ) : (
                      getChatIcon(chat.type)
                    )}
                  </div>
                  
                  {/* Online indicator */}
                  {chat.type === 'direct' && chat.isOnline && (
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full"></div>
                  )}
                  
                  {/* Pinned indicator */}
                  {chat.isPinned && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-gray-700 rounded-full flex items-center justify-center">
                      <Pin className="w-3 h-3 text-white transform rotate-45" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`font-semibold truncate ${chat.unreadCount > 0 ? 'text-gray-900' : 'text-gray-700'}`}>
                        {chat.name}
                      </span>
                      {chat.isMuted && (
                        <VolumeX className="w-4 h-4 text-gray-400 flex-shrink-0" />
                      )}
                    </div>
                    <span className={`text-xs flex-shrink-0 ml-2 ${
                      chat.unreadCount > 0 ? 'font-semibold' : 'text-gray-500'
                    }`} style={{ color: chat.unreadCount > 0 ? primaryColor : undefined }}>
                      {formatTime(chat.lastMessage?.timestamp)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className={`text-sm truncate flex-1 ${
                      chat.unreadCount > 0 ? 'text-gray-800 font-medium' : 'text-gray-500'
                    }`}>
                      {getMessagePreview(chat)}
                    </div>
                    
                    {/* Badges */}
                    <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                      {chat.unreadCount > 0 && (
                        <span 
                          className="min-w-[20px] h-5 px-1.5 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{ backgroundColor: chat.isMuted ? '#9ca3af' : primaryColor }}
                        >
                          {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Shift/Group info */}
                  {(chat.type === 'shift' || chat.type === 'group' || chat.type === 'channel') && chat.participants && (
                    <div className="flex items-center gap-1 mt-1 text-xs text-gray-400">
                      <Users className="w-3 h-3" />
                      <span>{chat.participants} members</span>
                    </div>
                  )}
                </div>
              </button>
            </div>
          ))
        )}

        {/* Archived Chats Link */}
        {chats.some(c => c.isArchived) && filter === 'all' && (
          <button className="w-full flex items-center justify-center gap-2 py-4 text-gray-500 hover:bg-gray-50">
            <Archive className="w-4 h-4" />
            <span className="text-sm">Archived ({chats.filter(c => c.isArchived).length})</span>
          </button>
        )}
      </div>

      {/* Bottom Safe Area */}
      <div style={{ height: 'env(safe-area-inset-bottom)' }}></div>
    </div>
  );
}

// ============================================================================
// STYLES (Add to your CSS)
// ============================================================================

/*
.scrollbar-hide::-webkit-scrollbar {
  display: none;
}
.scrollbar-hide {
  -ms-overflow-style: none;
  scrollbar-width: none;
}
*/
