// ============================================================================
// AUTOFORCE™ CHAT APP - Responsive Wrapper
// ============================================================================
// Automatically switches between mobile and desktop layouts
// Handles breakpoints, orientation changes, and shared state
// ============================================================================

import React, { useState, useEffect, createContext, useContext } from 'react';
import { io, Socket } from 'socket.io-client';
import MobileChatList from './MobileChatList';
import MobileChatView from './MobileChatView';
import DesktopChat from './DesktopChat';

// ============================================================================
// TYPES
// ============================================================================

interface ChatRoom {
  id: string;
  type: 'direct' | 'group' | 'shift' | 'channel' | 'support';
  name: string;
  avatar?: string;
  avatarColor?: string;
  participants?: number;
  lastMessage?: {
    content: string;
    senderId: string;
    senderName: string;
    type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location';
    timestamp: Date;
    isRead: boolean;
  };
  unreadCount: number;
  isOnline?: boolean;
  lastSeen?: Date;
  isTyping?: boolean;
  typingUser?: string;
  isPinned?: boolean;
  isMuted?: boolean;
  isArchived?: boolean;
}

interface ChatAppProps {
  userId: string;
  userName: string;
  userAvatar?: string;
  workspaceId: string;
  serverUrl?: string;
  primaryColor?: string;
  mobileBreakpoint?: number;
}

interface ChatContextValue {
  socket: Socket | null;
  connected: boolean;
  userId: string;
  userName: string;
  workspaceId: string;
  selectedChat: ChatRoom | null;
  setSelectedChat: (chat: ChatRoom | null) => void;
  chats: ChatRoom[];
  primaryColor: string;
}

// ============================================================================
// CONTEXT
// ============================================================================

const ChatContext = createContext<ChatContextValue | null>(null);

export const useChatContext = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChatContext must be used within ChatApp');
  }
  return context;
};

// ============================================================================
// RESPONSIVE HOOK
// ============================================================================

function useResponsive(breakpoint: number = 768) {
  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth < breakpoint;
  });

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < breakpoint);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [breakpoint]);

  return isMobile;
}

// ============================================================================
// CHAT APP COMPONENT
// ============================================================================

export default function ChatApp({
  userId,
  userName,
  userAvatar,
  workspaceId,
  serverUrl = 'http://localhost:3001',
  primaryColor = '#6366f1',
  mobileBreakpoint = 768,
}: ChatAppProps) {
  // Responsive
  const isMobile = useResponsive(mobileBreakpoint);

  // State
  const [socket, setSocket] = useState<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [selectedChat, setSelectedChat] = useState<ChatRoom | null>(null);
  const [chats, setChats] = useState<ChatRoom[]>([]);

  // ============================================================================
  // SOCKET CONNECTION
  // ============================================================================

  useEffect(() => {
    const newSocket = io(serverUrl, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5,
    });

    newSocket.on('connect', () => {
      console.log('🔌 Connected to chat server');
      setConnected(true);

      // Register user
      newSocket.emit('register', {
        id: userId,
        name: userName,
        avatar: userAvatar,
        role: 'customer',
        workspaceId,
      });
    });

    newSocket.on('disconnect', () => {
      console.log('🔌 Disconnected from chat server');
      setConnected(false);
    });

    newSocket.on('registered', () => {
      console.log('✅ User registered');
      // Load chats
      newSocket.emit('chats:load', { workspaceId });
    });

    newSocket.on('chats:loaded', (loadedChats: ChatRoom[]) => {
      setChats(loadedChats);
    });

    newSocket.on('chat:updated', (updatedChat: ChatRoom) => {
      setChats(prev => prev.map(c => c.id === updatedChat.id ? updatedChat : c));
    });

    newSocket.on('chat:new', (newChat: ChatRoom) => {
      setChats(prev => [newChat, ...prev]);
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, [serverUrl, userId, userName, userAvatar, workspaceId]);

  // ============================================================================
  // CONTEXT VALUE
  // ============================================================================

  const contextValue: ChatContextValue = {
    socket,
    connected,
    userId,
    userName,
    workspaceId,
    selectedChat,
    setSelectedChat,
    chats,
    primaryColor,
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <ChatContext.Provider value={contextValue}>
      {isMobile ? (
        <MobileChatApp
          userId={userId}
          workspaceId={workspaceId}
          primaryColor={primaryColor}
          selectedChat={selectedChat}
          setSelectedChat={setSelectedChat}
        />
      ) : (
        <DesktopChat
          userId={userId}
          userName={userName}
          userAvatar={userAvatar}
          workspaceId={workspaceId}
          serverUrl={serverUrl}
          primaryColor={primaryColor}
        />
      )}
    </ChatContext.Provider>
  );
}

// ============================================================================
// MOBILE APP WRAPPER (handles navigation)
// ============================================================================

interface MobileChatAppProps {
  userId: string;
  workspaceId: string;
  primaryColor: string;
  selectedChat: ChatRoom | null;
  setSelectedChat: (chat: ChatRoom | null) => void;
}

function MobileChatApp({
  userId,
  workspaceId,
  primaryColor,
  selectedChat,
  setSelectedChat,
}: MobileChatAppProps) {
  const handleSelectChat = (chat: ChatRoom) => {
    setSelectedChat(chat);
  };

  const handleBack = () => {
    setSelectedChat(null);
  };

  const handleNewChat = () => {
    // TODO: Open new chat modal
    console.log('New chat');
  };

  // Show chat view if a chat is selected, otherwise show list
  if (selectedChat) {
    return (
      <MobileChatView
        chat={selectedChat}
        userId={userId}
        onBack={handleBack}
        primaryColor={primaryColor}
      />
    );
  }

  return (
    <MobileChatList
      userId={userId}
      workspaceId={workspaceId}
      onSelectChat={handleSelectChat}
      onNewChat={handleNewChat}
      primaryColor={primaryColor}
    />
  );
}

// ============================================================================
// USAGE EXAMPLE
// ============================================================================

/*
import ChatApp from './ChatApp';

function App() {
  return (
    <ChatApp
      userId="user_123"
      userName="John Doe"
      workspaceId="workspace_456"
      serverUrl="http://localhost:3001"
      primaryColor="#6366f1"
    />
  );
}

// Or with custom breakpoint:
<ChatApp
  userId="user_123"
  userName="John Doe"
  workspaceId="workspace_456"
  mobileBreakpoint={1024} // Use mobile layout up to 1024px
/>
*/
