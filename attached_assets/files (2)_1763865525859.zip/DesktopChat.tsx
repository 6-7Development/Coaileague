// ============================================================================
// AUTOFORCE™ DESKTOP CHAT - Universal Page Layout
// ============================================================================
// Features:
// - Three-column layout (sidebar, chat list, conversation)
// - Resizable panels
// - Keyboard shortcuts
// - Rich message composer
// - Thread support ready
// - Full-featured like Slack/Teams
// ============================================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import {
  Search, Plus, MoreVertical, Users, User, Hash, Bell, BellOff,
  Archive, Trash2, Pin, Check, CheckCheck, Image, Mic, Video,
  Phone, FileText, MapPin, Clock, ChevronRight, Settings, Send,
  MessageCircle, Filter, X, Star, Volume2, VolumeX, Smile, Paperclip,
  AtSign, Bold, Italic, Link, Code, List, ChevronDown, ArrowLeft,
  Maximize2, Minimize2, Info, UserPlus, LogOut, Edit, Copy, Reply,
  Forward, Bookmark, MoreHorizontal, Bot, Zap, Calendar, Building2
} from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

interface ChatRoom {
  id: string;
  type: 'direct' | 'group' | 'shift' | 'channel' | 'support';
  name: string;
  avatar?: string;
  avatarColor?: string;
  participants?: number;
  description?: string;
  lastMessage?: {
    content: string;
    senderId: string;
    senderName: string;
    type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location';
    timestamp: Date;
    isRead: boolean;
  };
  unreadCount: number;
  isOnline?: boolean;
  lastSeen?: Date;
  isTyping?: boolean;
  typingUsers?: string[];
  isPinned?: boolean;
  isMuted?: boolean;
  isArchived?: boolean;
  members?: { id: string; name: string; avatar?: string; role?: string }[];
}

interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  senderRole: 'customer' | 'agent' | 'bot' | 'system';
  content: string;
  type: 'text' | 'file' | 'system' | 'ai-response';
  aiConfidence?: number;
  timestamp: Date;
  readBy: string[];
  reactions?: { emoji: string; users: string[] }[];
  replyTo?: Message;
  isEdited?: boolean;
}

interface DesktopChatProps {
  userId: string;
  userName: string;
  userAvatar?: string;
  workspaceId: string;
  serverUrl?: string;
  primaryColor?: string;
}

// ============================================================================
// MOCK DATA
// ============================================================================

const MOCK_WORKSPACES = [
  { id: '1', name: 'AutoForce HQ', icon: '🏢' },
  { id: '2', name: 'West Coast Team', icon: '🌴' },
];

const MOCK_CATEGORIES = [
  {
    id: 'shifts',
    name: 'Active Shifts',
    icon: Clock,
    color: '#10b981',
    chats: [
      { id: 's1', type: 'shift' as const, name: 'Morning Shift - Nov 21', participants: 8, unreadCount: 3, avatarColor: '#10b981', isPinned: true,
        lastMessage: { content: 'Can someone cover front desk?', senderId: 'u2', senderName: 'Sarah', type: 'text' as const, timestamp: new Date(Date.now() - 5*60000), isRead: false }
      },
      { id: 's2', type: 'shift' as const, name: 'Evening Shift - Nov 21', participants: 6, unreadCount: 0, avatarColor: '#14b8a6',
        lastMessage: { content: 'All set for tonight!', senderId: 'u3', senderName: 'Mike', type: 'text' as const, timestamp: new Date(Date.now() - 2*3600000), isRead: true }
      },
    ],
  },
  {
    id: 'channels',
    name: 'Channels',
    icon: Hash,
    color: '#6366f1',
    chats: [
      { id: 'c1', type: 'channel' as const, name: 'general', participants: 156, unreadCount: 0, avatarColor: '#6366f1',
        lastMessage: { content: 'Welcome to the team!', senderId: 'admin', senderName: 'HR', type: 'text' as const, timestamp: new Date(Date.now() - 12*3600000), isRead: true }
      },
      { id: 'c2', type: 'channel' as const, name: 'announcements', participants: 156, unreadCount: 1, avatarColor: '#ef4444', isPinned: true,
        lastMessage: { content: 'Holiday schedule posted', senderId: 'admin', senderName: 'Management', type: 'text' as const, timestamp: new Date(Date.now() - 24*3600000), isRead: false }
      },
      { id: 'c3', type: 'channel' as const, name: 'random', participants: 89, unreadCount: 0, avatarColor: '#f59e0b', isMuted: true,
        lastMessage: { content: '😂', senderId: 'u5', senderName: 'Emma', type: 'text' as const, timestamp: new Date(Date.now() - 48*3600000), isRead: true }
      },
    ],
  },
  {
    id: 'teams',
    name: 'Teams',
    icon: Users,
    color: '#f59e0b',
    chats: [
      { id: 't1', type: 'group' as const, name: 'Management', participants: 5, unreadCount: 0, avatarColor: '#f59e0b',
        lastMessage: { content: 'Q4 planning meeting at 3pm', senderId: 'u4', senderName: 'Lisa', type: 'text' as const, timestamp: new Date(Date.now() - 3*3600000), isRead: true }
      },
      { id: 't2', type: 'group' as const, name: 'Support Team', participants: 12, unreadCount: 2, avatarColor: '#8b5cf6',
        lastMessage: { content: 'New ticket assigned', senderId: 'system', senderName: 'System', type: 'text' as const, timestamp: new Date(Date.now() - 30*60000), isRead: false }
      },
    ],
  },
  {
    id: 'dms',
    name: 'Direct Messages',
    icon: MessageCircle,
    color: '#ec4899',
    chats: [
      { id: 'd1', type: 'direct' as const, name: 'Mike Johnson', unreadCount: 0, avatarColor: '#6366f1', isOnline: true,
        lastMessage: { content: 'Thanks for covering!', senderId: 'u3', senderName: 'Mike', type: 'text' as const, timestamp: new Date(Date.now() - 15*60000), isRead: true }
      },
      { id: 'd2', type: 'direct' as const, name: 'Emma Wilson', unreadCount: 0, avatarColor: '#ec4899', isOnline: false, isTyping: true,
        lastMessage: { content: 'See you tomorrow', senderId: 'u5', senderName: 'Emma', type: 'text' as const, timestamp: new Date(Date.now() - 3*3600000), isRead: true }
      },
      { id: 'd3', type: 'direct' as const, name: 'Sarah Chen', unreadCount: 1, avatarColor: '#10b981', isOnline: true,
        lastMessage: { content: 'Quick question about the schedule', senderId: 'u2', senderName: 'Sarah', type: 'text' as const, timestamp: new Date(Date.now() - 10*60000), isRead: false }
      },
    ],
  },
];

const MOCK_MESSAGES: Message[] = [
  {
    id: 'm1',
    conversationId: 's1',
    senderId: 'u2',
    senderName: 'Sarah Chen',
    senderRole: 'customer',
    content: 'Hey everyone! Can someone cover the front desk at 2pm? I have a doctor\'s appointment.',
    type: 'text',
    timestamp: new Date(Date.now() - 30 * 60000),
    readBy: ['u1', 'u3'],
    reactions: [{ emoji: '👍', users: ['u3', 'u4'] }],
  },
  {
    id: 'm2',
    conversationId: 's1',
    senderId: 'u3',
    senderName: 'Mike Johnson',
    senderRole: 'customer',
    content: 'I can cover! I\'ll be there by 1:45.',
    type: 'text',
    timestamp: new Date(Date.now() - 25 * 60000),
    readBy: ['u1', 'u2'],
  },
  {
    id: 'm3',
    conversationId: 's1',
    senderId: 'u2',
    senderName: 'Sarah Chen',
    senderRole: 'customer',
    content: 'Thank you so much Mike! 🙏',
    type: 'text',
    timestamp: new Date(Date.now() - 20 * 60000),
    readBy: ['u1', 'u3'],
  },
  {
    id: 'm4',
    conversationId: 's1',
    senderId: 'system',
    senderName: 'AutoForce',
    senderRole: 'bot',
    content: '📋 Shift swap request: Sarah Chen → Mike Johnson (2:00 PM - 3:00 PM). Pending manager approval.',
    type: 'system',
    timestamp: new Date(Date.now() - 15 * 60000),
    readBy: ['u1', 'u2', 'u3'],
  },
  {
    id: 'm5',
    conversationId: 's1',
    senderId: 'u4',
    senderName: 'Lisa Manager',
    senderRole: 'agent',
    content: '✅ Approved! Thanks for coordinating.',
    type: 'text',
    timestamp: new Date(Date.now() - 10 * 60000),
    readBy: ['u1', 'u2', 'u3'],
    reactions: [{ emoji: '🎉', users: ['u2', 'u3'] }],
  },
  {
    id: 'm6',
    conversationId: 's1',
    senderId: 'u5',
    senderName: 'Emma Wilson',
    senderRole: 'customer',
    content: 'Can someone help me with the new POS system? I\'m having trouble processing returns.',
    type: 'text',
    timestamp: new Date(Date.now() - 5 * 60000),
    readBy: ['u1'],
  },
];

// ============================================================================
// QUICK RESPONSES
// ============================================================================

const QUICK_RESPONSES = [
  { emoji: '👍', label: 'Thumbs up' },
  { emoji: '✅', label: 'Done' },
  { emoji: '🙏', label: 'Thanks' },
  { emoji: '👀', label: 'Looking' },
  { emoji: '🎉', label: 'Celebrate' },
];

// ============================================================================
// DESKTOP CHAT COMPONENT
// ============================================================================

export default function DesktopChat({
  userId,
  userName,
  userAvatar,
  workspaceId,
  serverUrl = 'http://localhost:3001',
  primaryColor = '#6366f1',
}: DesktopChatProps) {
  // State
  const [socket, setSocket] = useState<Socket | null>(null);
  const [selectedChat, setSelectedChat] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(
    new Set(MOCK_CATEGORIES.map(c => c.id))
  );
  const [showChatInfo, setShowChatInfo] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [hoveredMessageId, setHoveredMessageId] = useState<string | null>(null);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // ============================================================================
  // EFFECTS
  // ============================================================================

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Load messages when chat changes
  useEffect(() => {
    if (selectedChat) {
      setMessages(MOCK_MESSAGES.filter(m => m.conversationId === selectedChat.id));
    }
  }, [selectedChat?.id]);

  // ============================================================================
  // HANDLERS
  // ============================================================================

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(categoryId)) {
        next.delete(categoryId);
      } else {
        next.add(categoryId);
      }
      return next;
    });
  };

  const handleSend = () => {
    if (!inputValue.trim() || !selectedChat) return;

    const newMessage: Message = {
      id: `m_${Date.now()}`,
      conversationId: selectedChat.id,
      senderId: userId,
      senderName: userName,
      senderRole: 'customer',
      content: inputValue.trim(),
      type: 'text',
      timestamp: new Date(),
      readBy: [userId],
      replyTo: replyingTo || undefined,
    };

    setMessages(prev => [...prev, newMessage]);
    setInputValue('');
    setReplyingTo(null);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(m => {
      if (m.id !== messageId) return m;
      
      const reactions = m.reactions || [];
      const existing = reactions.find(r => r.emoji === emoji);
      
      if (existing) {
        if (existing.users.includes(userId)) {
          existing.users = existing.users.filter(u => u !== userId);
          if (existing.users.length === 0) {
            return { ...m, reactions: reactions.filter(r => r.emoji !== emoji) };
          }
        } else {
          existing.users.push(userId);
        }
        return { ...m, reactions: [...reactions] };
      } else {
        return { ...m, reactions: [...reactions, { emoji, users: [userId] }] };
      }
    }));
  };

  // ============================================================================
  // RENDER HELPERS
  // ============================================================================

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (24 * 3600000));
    
    if (days === 0) {
      return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    } else if (days === 1) {
      return 'Yesterday';
    } else if (days < 7) {
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const formatMessageTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const getChatIcon = (type: ChatRoom['type']) => {
    switch (type) {
      case 'channel': return <Hash className="w-4 h-4" />;
      case 'shift': return <Clock className="w-4 h-4" />;
      case 'group': return <Users className="w-4 h-4" />;
      default: return null;
    }
  };

  const getTotalUnread = () => {
    return MOCK_CATEGORIES.reduce((sum, cat) => 
      sum + cat.chats.reduce((s, c) => s + c.unreadCount, 0), 0
    );
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="h-screen flex bg-gray-100">
      {/* ================================================================== */}
      {/* SIDEBAR - Workspaces & Navigation */}
      {/* ================================================================== */}
      <div className="w-16 bg-gray-900 flex flex-col items-center py-4 gap-3">
        {/* Workspace Icons */}
        {MOCK_WORKSPACES.map((ws, i) => (
          <button
            key={ws.id}
            className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg transition-all hover:rounded-2xl ${
              i === 0 ? 'bg-indigo-600' : 'bg-gray-700 hover:bg-gray-600'
            }`}
            title={ws.name}
          >
            {ws.icon}
          </button>
        ))}
        
        {/* Add Workspace */}
        <button className="w-11 h-11 rounded-xl bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-gray-700 hover:text-white transition-colors">
          <Plus className="w-5 h-5" />
        </button>

        <div className="flex-1" />

        {/* Bottom Icons */}
        <button className="w-11 h-11 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-800 hover:text-white transition-colors relative">
          <Bell className="w-5 h-5" />
          {getTotalUnread() > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
              {getTotalUnread()}
            </span>
          )}
        </button>
        <button className="w-11 h-11 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-800 hover:text-white transition-colors">
          <Settings className="w-5 h-5" />
        </button>
        
        {/* User Avatar */}
        <div className="w-11 h-11 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-semibold cursor-pointer hover:ring-2 hover:ring-white transition-all">
          {userAvatar ? (
            <img src={userAvatar} alt="" className="w-full h-full rounded-xl object-cover" />
          ) : (
            userName.charAt(0).toUpperCase()
          )}
        </div>
      </div>

      {/* ================================================================== */}
      {/* CHAT LIST - Categories & Rooms */}
      {/* ================================================================== */}
      <div className="w-64 bg-gray-800 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-700">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-white font-bold text-lg">AutoForce HQ</h2>
            <button className="text-gray-400 hover:text-white">
              <ChevronDown className="w-5 h-5" />
            </button>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-gray-900 text-white text-sm rounded-md placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex-1 overflow-y-auto py-2">
          {MOCK_CATEGORIES.map((category) => (
            <div key={category.id} className="mb-1">
              {/* Category Header */}
              <button
                onClick={() => toggleCategory(category.id)}
                className="w-full flex items-center gap-2 px-4 py-1.5 text-gray-400 hover:text-white transition-colors group"
              >
                <ChevronRight 
                  className={`w-3 h-3 transition-transform ${expandedCategories.has(category.id) ? 'rotate-90' : ''}`} 
                />
                <category.icon className="w-4 h-4" style={{ color: category.color }} />
                <span className="text-xs font-semibold uppercase tracking-wide flex-1 text-left">
                  {category.name}
                </span>
                {category.chats.reduce((sum, c) => sum + c.unreadCount, 0) > 0 && (
                  <span className="text-xs bg-red-500 text-white px-1.5 rounded-full">
                    {category.chats.reduce((sum, c) => sum + c.unreadCount, 0)}
                  </span>
                )}
                <Plus className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>

              {/* Category Chats */}
              {expandedCategories.has(category.id) && (
                <div className="mt-0.5">
                  {category.chats.map((chat) => (
                    <button
                      key={chat.id}
                      onClick={() => setSelectedChat(chat as ChatRoom)}
                      className={`w-full flex items-center gap-2 px-4 py-1.5 transition-colors group ${
                        selectedChat?.id === chat.id
                          ? 'bg-indigo-600 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      {/* Icon or Avatar */}
                      {chat.type === 'direct' ? (
                        <div className="relative">
                          <div 
                            className="w-6 h-6 rounded-md flex items-center justify-center text-white text-xs font-medium"
                            style={{ backgroundColor: chat.avatarColor }}
                          >
                            {chat.name.charAt(0)}
                          </div>
                          {chat.isOnline && (
                            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-gray-800"></div>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">
                          {getChatIcon(chat.type)}
                        </span>
                      )}
                      
                      {/* Name */}
                      <span className={`flex-1 text-sm truncate text-left ${
                        chat.unreadCount > 0 ? 'font-semibold' : ''
                      }`}>
                        {chat.type === 'channel' ? `#${chat.name}` : chat.name}
                      </span>

                      {/* Indicators */}
                      {chat.isMuted && (
                        <VolumeX className="w-3 h-3 text-gray-500" />
                      )}
                      {chat.isTyping && (
                        <div className="flex gap-0.5">
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                        </div>
                      )}
                      {chat.unreadCount > 0 && (
                        <span className={`min-w-[18px] h-[18px] text-xs font-bold rounded-full flex items-center justify-center ${
                          selectedChat?.id === chat.id
                            ? 'bg-white text-indigo-600'
                            : 'bg-red-500 text-white'
                        }`}>
                          {chat.unreadCount}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* User Status */}
        <div className="p-3 border-t border-gray-700">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-medium">
                {userName.charAt(0)}
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-800"></div>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{userName}</p>
              <p className="text-gray-400 text-xs">Online</p>
            </div>
          </div>
        </div>
      </div>

      {/* ================================================================== */}
      {/* MAIN CHAT AREA */}
      {/* ================================================================== */}
      <div className="flex-1 flex flex-col bg-white">
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="h-16 px-6 flex items-center justify-between border-b bg-white">
              <div className="flex items-center gap-3">
                {selectedChat.type === 'direct' ? (
                  <div className="relative">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-semibold"
                      style={{ backgroundColor: selectedChat.avatarColor }}
                    >
                      {selectedChat.name.charAt(0)}
                    </div>
                    {selectedChat.isOnline && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                    )}
                  </div>
                ) : (
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-white"
                    style={{ backgroundColor: selectedChat.avatarColor }}
                  >
                    {getChatIcon(selectedChat.type)}
                  </div>
                )}
                <div>
                  <h2 className="font-semibold text-gray-900">
                    {selectedChat.type === 'channel' ? `#${selectedChat.name}` : selectedChat.name}
                  </h2>
                  <p className="text-sm text-gray-500">
                    {selectedChat.type === 'direct' 
                      ? (selectedChat.isOnline ? 'Online' : 'Offline')
                      : `${selectedChat.participants} members`
                    }
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-gray-700">
                  <Phone className="w-5 h-5" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-gray-700">
                  <Video className="w-5 h-5" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-gray-700">
                  <Search className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setShowChatInfo(!showChatInfo)}
                  className={`p-2 rounded-lg ${showChatInfo ? 'bg-indigo-100 text-indigo-600' : 'hover:bg-gray-100 text-gray-500 hover:text-gray-700'}`}
                >
                  <Info className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {messages.map((message, index) => {
                const isOwn = message.senderId === userId;
                const isSystem = message.senderRole === 'bot' || message.senderRole === 'system';
                const showAvatar = index === 0 || messages[index - 1]?.senderId !== message.senderId;
                const showTime = index === messages.length - 1 || 
                  messages[index + 1]?.senderId !== message.senderId ||
                  (messages[index + 1]?.timestamp.getTime() - message.timestamp.getTime() > 5 * 60000);

                if (isSystem) {
                  return (
                    <div key={message.id} className="flex justify-center my-4">
                      <div className="bg-gray-100 text-gray-600 text-sm px-4 py-2 rounded-lg max-w-md">
                        {message.content}
                      </div>
                    </div>
                  );
                }

                return (
                  <div 
                    key={message.id}
                    className={`flex gap-3 mb-1 group ${showAvatar ? 'mt-4' : ''}`}
                    onMouseEnter={() => setHoveredMessageId(message.id)}
                    onMouseLeave={() => setHoveredMessageId(null)}
                  >
                    {/* Avatar */}
                    <div className="w-9 flex-shrink-0">
                      {showAvatar && (
                        <div 
                          className="w-9 h-9 rounded-lg flex items-center justify-center text-white text-sm font-medium"
                          style={{ backgroundColor: isOwn ? primaryColor : '#6b7280' }}
                        >
                          {message.senderName.charAt(0)}
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      {showAvatar && (
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="font-semibold text-gray-900">{message.senderName}</span>
                          <span className="text-xs text-gray-500">{formatMessageTime(message.timestamp)}</span>
                        </div>
                      )}

                      {/* Reply indicator */}
                      {message.replyTo && (
                        <div className="flex items-center gap-2 mb-1 text-sm text-gray-500 border-l-2 border-gray-300 pl-2">
                          <Reply className="w-3 h-3" />
                          <span className="font-medium">{message.replyTo.senderName}:</span>
                          <span className="truncate">{message.replyTo.content}</span>
                        </div>
                      )}

                      <div className="relative">
                        <p className="text-gray-800 whitespace-pre-wrap break-words">
                          {message.content}
                        </p>

                        {/* Reactions */}
                        {message.reactions && message.reactions.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {message.reactions.map((reaction) => (
                              <button
                                key={reaction.emoji}
                                onClick={() => handleReaction(message.id, reaction.emoji)}
                                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-sm transition-colors ${
                                  reaction.users.includes(userId)
                                    ? 'bg-indigo-100 text-indigo-700'
                                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                }`}
                              >
                                <span>{reaction.emoji}</span>
                                <span className="text-xs">{reaction.users.length}</span>
                              </button>
                            ))}
                          </div>
                        )}

                        {/* Action buttons */}
                        {hoveredMessageId === message.id && (
                          <div className="absolute -top-8 right-0 flex items-center gap-0.5 bg-white border rounded-lg shadow-lg p-0.5">
                            {QUICK_RESPONSES.slice(0, 3).map((r) => (
                              <button
                                key={r.emoji}
                                onClick={() => handleReaction(message.id, r.emoji)}
                                className="w-7 h-7 flex items-center justify-center hover:bg-gray-100 rounded"
                                title={r.label}
                              >
                                {r.emoji}
                              </button>
                            ))}
                            <div className="w-px h-5 bg-gray-200 mx-0.5"></div>
                            <button
                              onClick={() => setReplyingTo(message)}
                              className="w-7 h-7 flex items-center justify-center hover:bg-gray-100 rounded text-gray-500"
                              title="Reply"
                            >
                              <Reply className="w-4 h-4" />
                            </button>
                            <button className="w-7 h-7 flex items-center justify-center hover:bg-gray-100 rounded text-gray-500" title="More">
                              <MoreHorizontal className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Reply Preview */}
            {replyingTo && (
              <div className="px-6 py-2 bg-gray-50 border-t flex items-center gap-3">
                <div className="w-1 h-10 bg-indigo-500 rounded"></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-indigo-600">Replying to {replyingTo.senderName}</p>
                  <p className="text-sm text-gray-500 truncate">{replyingTo.content}</p>
                </div>
                <button onClick={() => setReplyingTo(null)} className="p-1 hover:bg-gray-200 rounded">
                  <X className="w-4 h-4 text-gray-500" />
                </button>
              </div>
            )}

            {/* Typing Indicator */}
            {typingUsers.length > 0 && (
              <div className="px-6 py-2 text-sm text-gray-500">
                <span className="font-medium">{typingUsers.join(', ')}</span> is typing...
              </div>
            )}

            {/* Input Area */}
            <div className="px-6 py-4 border-t bg-white">
              <div className="flex items-end gap-3">
                <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500">
                  <Plus className="w-5 h-5" />
                </button>
                
                <div className="flex-1 relative">
                  <textarea
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={`Message ${selectedChat.type === 'channel' ? '#' : ''}${selectedChat.name}`}
                    rows={1}
                    className="w-full px-4 py-3 bg-gray-100 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                    style={{ maxHeight: '120px' }}
                  />
                </div>

                <div className="flex items-center gap-1">
                  <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500">
                    <AtSign className="w-5 h-5" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500">
                    <Smile className="w-5 h-5" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg text-gray-500">
                    <Paperclip className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleSend}
                    disabled={!inputValue.trim()}
                    className="p-2 rounded-lg text-white disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
                    style={{ backgroundColor: primaryColor }}
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </>
        ) : (
          /* Empty State */
          <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <MessageCircle className="w-12 h-12 text-gray-300" />
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Select a conversation</h3>
            <p className="text-gray-500">Choose a chat from the sidebar to start messaging</p>
          </div>
        )}
      </div>

      {/* ================================================================== */}
      {/* CHAT INFO PANEL */}
      {/* ================================================================== */}
      {showChatInfo && selectedChat && (
        <div className="w-80 border-l bg-white flex flex-col">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-semibold">Details</h3>
            <button onClick={() => setShowChatInfo(false)} className="p-1 hover:bg-gray-100 rounded">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {/* Avatar & Name */}
            <div className="flex flex-col items-center mb-6">
              <div 
                className="w-20 h-20 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mb-3"
                style={{ backgroundColor: selectedChat.avatarColor }}
              >
                {selectedChat.type === 'direct' 
                  ? selectedChat.name.charAt(0)
                  : getChatIcon(selectedChat.type)
                }
              </div>
              <h3 className="text-lg font-semibold">{selectedChat.name}</h3>
              <p className="text-gray-500 text-sm">
                {selectedChat.type === 'direct' 
                  ? (selectedChat.isOnline ? 'Online' : 'Last seen recently')
                  : `${selectedChat.participants} members`
                }
              </p>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-3 gap-2 mb-6">
              <button className="flex flex-col items-center gap-1 p-3 hover:bg-gray-100 rounded-xl">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="text-xs text-gray-600">Mute</span>
              </button>
              <button className="flex flex-col items-center gap-1 p-3 hover:bg-gray-100 rounded-xl">
                <Star className="w-5 h-5 text-gray-600" />
                <span className="text-xs text-gray-600">Star</span>
              </button>
              <button className="flex flex-col items-center gap-1 p-3 hover:bg-gray-100 rounded-xl">
                <Search className="w-5 h-5 text-gray-600" />
                <span className="text-xs text-gray-600">Search</span>
              </button>
            </div>

            {/* Members */}
            {selectedChat.type !== 'direct' && (
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3">Members</h4>
                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg">
                      <div className="w-9 h-9 rounded-lg bg-gray-300 flex items-center justify-center text-white text-sm">
                        {String.fromCharCode(64 + i)}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Member {i}</p>
                        <p className="text-xs text-gray-500">Online</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Shared Media */}
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-700 mb-3">Shared Media</h4>
              <div className="grid grid-cols-3 gap-1">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="aspect-square bg-gray-100 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
