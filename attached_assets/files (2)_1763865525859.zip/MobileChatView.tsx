// ============================================================================
// AUTOFORCE™ MOBILE CHAT VIEW - Individual Conversation
// ============================================================================
// Features:
// - Full-screen chat experience
// - iOS/Android-like interface
// - Swipe gestures
// - Image/file preview
// - Voice message ready
// - Reactions
// ============================================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft, MoreVertical, Phone, Video, Send, Paperclip, Mic, Camera,
  Image, Smile, Check, CheckCheck, Reply, Copy, Forward, Trash2,
  Pin, Star, Clock, Users, Hash, User, Bot, X, ChevronDown,
  Play, Pause, File, MapPin
} from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

interface ChatRoom {
  id: string;
  type: 'direct' | 'group' | 'shift' | 'channel' | 'support';
  name: string;
  avatar?: string;
  avatarColor?: string;
  participants?: number;
  isOnline?: boolean;
  isTyping?: boolean;
  typingUsers?: string[];
}

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  type: 'text' | 'image' | 'video' | 'audio' | 'file' | 'location' | 'system';
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  duration?: number; // For audio/video
  timestamp: Date;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  replyTo?: Message;
  reactions?: { emoji: string; users: string[] }[];
}

interface MobileChatViewProps {
  chat: ChatRoom;
  userId: string;
  onBack: () => void;
  primaryColor?: string;
}

// ============================================================================
// MOCK DATA
// ============================================================================

const MOCK_MESSAGES: Message[] = [
  {
    id: '1',
    senderId: 'user_2',
    senderName: 'Sarah Chen',
    content: 'Hey! Can someone cover the front desk at 2pm? I have a doctor\'s appointment.',
    type: 'text',
    timestamp: new Date(Date.now() - 30 * 60000),
    status: 'read',
    reactions: [{ emoji: '👍', users: ['user_3', 'user_4'] }],
  },
  {
    id: '2',
    senderId: 'user_3',
    senderName: 'Mike Johnson',
    content: 'I can cover! I\'ll be there by 1:45.',
    type: 'text',
    timestamp: new Date(Date.now() - 25 * 60000),
    status: 'read',
  },
  {
    id: '3',
    senderId: 'user_2',
    senderName: 'Sarah Chen',
    content: 'Thank you so much Mike! 🙏',
    type: 'text',
    timestamp: new Date(Date.now() - 20 * 60000),
    status: 'read',
  },
  {
    id: '4',
    senderId: 'system',
    senderName: 'System',
    content: '📋 Shift swap request: Sarah Chen → Mike Johnson (2:00 PM - 3:00 PM)',
    type: 'system',
    timestamp: new Date(Date.now() - 15 * 60000),
    status: 'read',
  },
  {
    id: '5',
    senderId: 'user_4',
    senderName: 'Lisa Manager',
    content: '✅ Approved!',
    type: 'text',
    timestamp: new Date(Date.now() - 10 * 60000),
    status: 'read',
    reactions: [{ emoji: '🎉', users: ['user_2', 'user_3'] }],
  },
  {
    id: '6',
    senderId: 'user_5',
    senderName: 'Emma Wilson',
    content: 'Can someone help me with the new POS system? I\'m having trouble processing returns.',
    type: 'text',
    timestamp: new Date(Date.now() - 5 * 60000),
    status: 'delivered',
  },
];

const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

// ============================================================================
// MOBILE CHAT VIEW COMPONENT
// ============================================================================

export default function MobileChatView({
  chat,
  userId,
  onBack,
  primaryColor = '#6366f1',
}: MobileChatViewProps) {
  // State
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showScrollDown, setShowScrollDown] = useState(false);

  // Refs
  const messagesRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // ============================================================================
  // EFFECTS
  // ============================================================================

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const handleScroll = () => {
      if (!messagesRef.current) return;
      const { scrollTop, scrollHeight, clientHeight } = messagesRef.current;
      setShowScrollDown(scrollHeight - scrollTop - clientHeight > 200);
    };

    messagesRef.current?.addEventListener('scroll', handleScroll);
    return () => messagesRef.current?.removeEventListener('scroll', handleScroll);
  }, []);

  // ============================================================================
  // HANDLERS
  // ============================================================================

  const scrollToBottom = () => {
    messagesRef.current?.scrollTo({
      top: messagesRef.current.scrollHeight,
      behavior: 'smooth',
    });
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: `msg_${Date.now()}`,
      senderId: userId,
      senderName: 'You',
      content: inputValue.trim(),
      type: 'text',
      timestamp: new Date(),
      status: 'sending',
      replyTo: replyingTo || undefined,
    };

    setMessages(prev => [...prev, newMessage]);
    setInputValue('');
    setReplyingTo(null);

    // Simulate send
    setTimeout(() => {
      setMessages(prev =>
        prev.map(m => m.id === newMessage.id ? { ...m, status: 'sent' as const } : m)
      );
    }, 500);

    setTimeout(() => {
      setMessages(prev =>
        prev.map(m => m.id === newMessage.id ? { ...m, status: 'delivered' as const } : m)
      );
    }, 1000);
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(m => {
      if (m.id !== messageId) return m;

      const reactions = m.reactions || [];
      const existing = reactions.find(r => r.emoji === emoji);

      if (existing) {
        if (existing.users.includes(userId)) {
          existing.users = existing.users.filter(u => u !== userId);
          if (existing.users.length === 0) {
            return { ...m, reactions: reactions.filter(r => r.emoji !== emoji) };
          }
        } else {
          existing.users.push(userId);
        }
        return { ...m, reactions: [...reactions] };
      } else {
        return { ...m, reactions: [...reactions, { emoji, users: [userId] }] };
      }
    }));
    setSelectedMessage(null);
  };

  const handleLongPress = (message: Message) => {
    // Vibrate if available
    if (navigator.vibrate) navigator.vibrate(50);
    setSelectedMessage(message);
  };

  // ============================================================================
  // RENDER HELPERS
  // ============================================================================

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) return 'Today';
    if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return date.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  };

  const getStatusIcon = (status: Message['status']) => {
    switch (status) {
      case 'sending':
        return <Clock className="w-3 h-3 text-gray-400" />;
      case 'sent':
        return <Check className="w-3 h-3 text-gray-400" />;
      case 'delivered':
        return <CheckCheck className="w-3 h-3 text-gray-400" />;
      case 'read':
        return <CheckCheck className="w-3 h-3 text-blue-500" />;
    }
  };

  const getChatTypeIcon = () => {
    switch (chat.type) {
      case 'shift': return <Clock className="w-4 h-4" />;
      case 'channel': return <Hash className="w-4 h-4" />;
      case 'group': return <Users className="w-4 h-4" />;
      default: return null;
    }
  };

  // Group messages by date
  const groupedMessages = messages.reduce((groups, message) => {
    const date = message.timestamp.toDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {} as Record<string, Message[]>);

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="h-full flex flex-col bg-gray-100">
      {/* Header */}
      <div
        className="sticky top-0 z-20 bg-white border-b px-2 py-3 flex items-center gap-2"
        style={{ paddingTop: 'max(0.75rem, env(safe-area-inset-top))' }}
      >
        <button
          onClick={onBack}
          className="p-2 -ml-1 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>

        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="relative">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold"
              style={{ backgroundColor: chat.avatarColor || primaryColor }}
            >
              {chat.type === 'direct' ? chat.name.charAt(0) : getChatTypeIcon()}
            </div>
            {chat.type === 'direct' && chat.isOnline && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h2 className="font-semibold text-gray-900 truncate">{chat.name}</h2>
            <p className="text-xs text-gray-500 truncate">
              {chat.isTyping ? (
                <span className="text-green-600">typing...</span>
              ) : chat.type === 'direct' ? (
                chat.isOnline ? 'Online' : 'Last seen recently'
              ) : (
                `${chat.participants} members`
              )}
            </p>
          </div>
        </div>

        <button className="p-2 hover:bg-gray-100 rounded-full">
          <Video className="w-5 h-5 text-gray-600" />
        </button>
        <button className="p-2 hover:bg-gray-100 rounded-full">
          <Phone className="w-5 h-5 text-gray-600" />
        </button>
        <button className="p-2 hover:bg-gray-100 rounded-full">
          <MoreVertical className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Messages */}
      <div
        ref={messagesRef}
        className="flex-1 overflow-y-auto px-3 py-4"
        style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23e5e7eb\' fill-opacity=\'0.4\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
        }}
      >
        {Object.entries(groupedMessages).map(([date, dateMessages]) => (
          <div key={date}>
            {/* Date Divider */}
            <div className="flex justify-center my-4">
              <span className="bg-white text-gray-500 text-xs px-3 py-1 rounded-full shadow-sm">
                {formatDate(new Date(date))}
              </span>
            </div>

            {/* Messages for this date */}
            {dateMessages.map((message, index) => {
              const isOwn = message.senderId === userId;
              const isSystem = message.type === 'system';
              const showSender = !isOwn && chat.type !== 'direct' && 
                (index === 0 || dateMessages[index - 1]?.senderId !== message.senderId);

              if (isSystem) {
                return (
                  <div key={message.id} className="flex justify-center my-3">
                    <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 text-sm px-4 py-2 rounded-lg max-w-[85%]">
                      {message.content}
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={message.id}
                  className={`flex mb-1 ${isOwn ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[75%] ${showSender ? 'mt-2' : ''}`}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      handleLongPress(message);
                    }}
                  >
                    {/* Sender name */}
                    {showSender && (
                      <p className="text-xs font-medium text-gray-500 mb-1 ml-3">
                        {message.senderName}
                      </p>
                    )}

                    {/* Reply preview */}
                    {message.replyTo && (
                      <div className={`flex items-center gap-2 px-3 py-1 mb-1 rounded-t-xl text-xs ${
                        isOwn ? 'bg-indigo-700 text-indigo-200' : 'bg-gray-300 text-gray-600'
                      }`}>
                        <Reply className="w-3 h-3" />
                        <span className="font-medium">{message.replyTo.senderName}</span>
                        <span className="truncate">{message.replyTo.content}</span>
                      </div>
                    )}

                    {/* Message bubble */}
                    <div
                      className={`px-3 py-2 rounded-2xl ${
                        isOwn
                          ? 'rounded-br-md text-white'
                          : 'rounded-bl-md bg-white text-gray-800 shadow-sm'
                      } ${message.replyTo ? 'rounded-t-none' : ''}`}
                      style={{ backgroundColor: isOwn ? primaryColor : undefined }}
                    >
                      {/* Image message */}
                      {message.type === 'image' && message.fileUrl && (
                        <img
                          src={message.fileUrl}
                          alt=""
                          className="rounded-lg max-w-full mb-1"
                        />
                      )}

                      {/* Audio message */}
                      {message.type === 'audio' && (
                        <div className="flex items-center gap-2 min-w-[200px]">
                          <button className="w-8 h-8 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
                            <Play className="w-4 h-4" />
                          </button>
                          <div className="flex-1 h-1 bg-white bg-opacity-30 rounded-full">
                            <div className="w-1/3 h-full bg-white rounded-full"></div>
                          </div>
                          <span className="text-xs opacity-70">0:24</span>
                        </div>
                      )}

                      {/* File message */}
                      {message.type === 'file' && (
                        <div className="flex items-center gap-2 min-w-[200px]">
                          <div className="w-10 h-10 rounded-lg bg-white bg-opacity-20 flex items-center justify-center">
                            <File className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{message.fileName}</p>
                            <p className="text-xs opacity-70">{message.fileSize} KB</p>
                          </div>
                        </div>
                      )}

                      {/* Text content */}
                      {message.type === 'text' && (
                        <p className="text-[15px] whitespace-pre-wrap break-words">
                          {message.content}
                        </p>
                      )}

                      {/* Time & Status */}
                      <div className={`flex items-center justify-end gap-1 mt-1 ${
                        isOwn ? 'text-white text-opacity-70' : 'text-gray-400'
                      }`}>
                        <span className="text-[10px]">{formatTime(message.timestamp)}</span>
                        {isOwn && getStatusIcon(message.status)}
                      </div>
                    </div>

                    {/* Reactions */}
                    {message.reactions && message.reactions.length > 0 && (
                      <div className={`flex flex-wrap gap-1 mt-1 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                        {message.reactions.map((reaction) => (
                          <button
                            key={reaction.emoji}
                            onClick={() => handleReaction(message.id, reaction.emoji)}
                            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-sm shadow-sm ${
                              reaction.users.includes(userId)
                                ? 'bg-indigo-100'
                                : 'bg-white'
                            }`}
                          >
                            <span>{reaction.emoji}</span>
                            <span className="text-xs text-gray-600">{reaction.users.length}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* Scroll to bottom button */}
      {showScrollDown && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-24 right-4 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center"
        >
          <ChevronDown className="w-5 h-5 text-gray-600" />
        </button>
      )}

      {/* Reply Preview */}
      {replyingTo && (
        <div className="bg-gray-50 border-t px-4 py-2 flex items-center gap-3">
          <div className="w-1 h-10 rounded" style={{ backgroundColor: primaryColor }}></div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium" style={{ color: primaryColor }}>
              Replying to {replyingTo.senderName}
            </p>
            <p className="text-sm text-gray-500 truncate">{replyingTo.content}</p>
          </div>
          <button onClick={() => setReplyingTo(null)} className="p-2">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      )}

      {/* Input Area */}
      <div
        className="bg-white border-t px-3 py-2"
        style={{ paddingBottom: 'max(0.5rem, env(safe-area-inset-bottom))' }}
      >
        <div className="flex items-end gap-2">
          {/* Attach Button */}
          <button
            onClick={() => setShowAttachMenu(!showAttachMenu)}
            className="p-2 rounded-full hover:bg-gray-100"
          >
            <Paperclip className="w-6 h-6 text-gray-500" />
          </button>

          {/* Input */}
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Message..."
              className="w-full px-4 py-2.5 bg-gray-100 rounded-full focus:outline-none focus:ring-2 text-[15px]"
              style={{ '--tw-ring-color': primaryColor } as any}
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2">
              <Smile className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* Send or Mic Button */}
          {inputValue.trim() ? (
            <button
              onClick={handleSend}
              className="w-11 h-11 rounded-full flex items-center justify-center text-white"
              style={{ backgroundColor: primaryColor }}
            >
              <Send className="w-5 h-5" />
            </button>
          ) : (
            <button
              onTouchStart={() => setIsRecording(true)}
              onTouchEnd={() => setIsRecording(false)}
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors ${
                isRecording ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-600'
              }`}
            >
              <Mic className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Attach Menu */}
        {showAttachMenu && (
          <div className="flex gap-4 justify-center py-4 mt-2">
            {[
              { icon: Image, label: 'Photo', color: '#8b5cf6' },
              { icon: Camera, label: 'Camera', color: '#ef4444' },
              { icon: File, label: 'Document', color: '#6366f1' },
              { icon: MapPin, label: 'Location', color: '#10b981' },
            ].map((item) => (
              <button
                key={item.label}
                className="flex flex-col items-center gap-1"
                onClick={() => setShowAttachMenu(false)}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center text-white"
                  style={{ backgroundColor: item.color }}
                >
                  <item.icon className="w-5 h-5" />
                </div>
                <span className="text-xs text-gray-600">{item.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Message Action Sheet */}
      {selectedMessage && (
        <div
          className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-end justify-center"
          onClick={() => setSelectedMessage(null)}
        >
          <div
            className="bg-white w-full max-w-lg rounded-t-3xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
          >
            {/* Quick Reactions */}
            <div className="flex justify-center gap-4 py-4 border-b">
              {QUICK_REACTIONS.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handleReaction(selectedMessage.id, emoji)}
                  className="text-2xl hover:scale-125 transition-transform active:scale-95"
                >
                  {emoji}
                </button>
              ))}
            </div>

            {/* Actions */}
            <div className="py-2">
              {[
                { icon: Reply, label: 'Reply', action: () => { setReplyingTo(selectedMessage); setSelectedMessage(null); } },
                { icon: Copy, label: 'Copy', action: () => { navigator.clipboard.writeText(selectedMessage.content); setSelectedMessage(null); } },
                { icon: Forward, label: 'Forward', action: () => setSelectedMessage(null) },
                { icon: Pin, label: 'Pin', action: () => setSelectedMessage(null) },
                { icon: Star, label: 'Star', action: () => setSelectedMessage(null) },
              ].map((item) => (
                <button
                  key={item.label}
                  onClick={item.action}
                  className="w-full flex items-center gap-4 px-6 py-3 hover:bg-gray-50 active:bg-gray-100"
                >
                  <item.icon className="w-5 h-5 text-gray-500" />
                  <span className="text-gray-700">{item.label}</span>
                </button>
              ))}

              {selectedMessage.senderId === userId && (
                <button
                  className="w-full flex items-center gap-4 px-6 py-3 hover:bg-gray-50 active:bg-gray-100 text-red-500"
                  onClick={() => {
                    setMessages(prev => prev.filter(m => m.id !== selectedMessage.id));
                    setSelectedMessage(null);
                  }}
                >
                  <Trash2 className="w-5 h-5" />
                  <span>Delete</span>
                </button>
              )}
            </div>

            {/* Cancel */}
            <button
              onClick={() => setSelectedMessage(null)}
              className="w-full py-4 border-t font-medium text-gray-500"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
